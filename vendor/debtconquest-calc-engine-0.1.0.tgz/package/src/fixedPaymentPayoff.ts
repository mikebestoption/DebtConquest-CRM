export interface FixedPaymentPayoffResult {
  months: number;
  totalPaid: number;
}

/**
 * Single blended-balance amortization at a FIXED monthly payment amount
 * (the user's current budget), rather than a percentage of balance. This is
 * genuinely different math from `simulateSingleBalancePayoff` - legacy kept
 * it as a separate function (`calculateWithoutCard`, script.js:1807) with its
 * own rounding (whole-dollar interest via `Math.round`, not cents) and its
 * own loop guard (look-ahead `amounttocheck > emi` rather than a balance
 * threshold), so it's ported here as its own function instead of forced into
 * the percent-of-balance unification.
 */
export function simulateFixedPaymentPayoff(
  balance: number,
  annualInterestRatePercent: number,
  monthlyPayment: number,
): FixedPaymentPayoffResult {
  const interestRate = Math.trunc(annualInterestRatePercent) / 12 / 100;
  let months = 0;
  let totalPaid = 0;
  let amountToCheck = balance;

  while (amountToCheck > monthlyPayment) {
    const interest = Math.round(balance * interestRate);
    balance = Math.round((balance + interest - monthlyPayment) * 100) / 100;
    const nextInterest = Math.round(balance * interestRate);
    amountToCheck = balance + nextInterest;
    totalPaid = Math.round((totalPaid + monthlyPayment) * 100) / 100;
    months++;
  }

  if (balance > 0) {
    totalPaid = Math.round((totalPaid + balance) * 100) / 100;
    months++;
  }

  return { months, totalPaid };
}
