/**
 * Projects the future value of a fixed monthly deposit, compounding annually
 * for each full remaining year and prorating simple interest for a final
 * partial year. Ports `futureValueAnnualCompounding()` from legacy
 * script.js:1295, but takes an explicit integer `totalMonths` instead of the
 * legacy "years.months" decimal notation (e.g. legacy `4.6` meant "4 years
 * 6 months", NOT 4.6 years - a real footgun). Convert at the UI boundary
 * with `yearsAndMonthsToTotalMonths` below; no internal code should ever
 * re-parse that ambiguous notation again.
 */
export function calculateWealthGrowth(
  monthlyDeposit: number,
  totalMonths: number,
  annualRatePercent: number,
): number {
  const r = annualRatePercent / 100;
  let total = 0;
  for (let m = 0; m < totalMonths; m++) {
    const remaining = totalMonths - m;
    const fullYears = Math.floor(remaining / 12);
    const remMonths = remaining % 12;
    total += monthlyDeposit * Math.pow(1 + r, fullYears) * (1 + r * (remMonths / 12));
  }
  return Number(total.toFixed(2));
}

/**
 * Converts legacy's ambiguous "years.months" decimal (e.g. 4.6 = 4y 6mo)
 * into a plain integer month count, for compatibility at the UI boundary
 * only.
 */
export function yearsAndMonthsToTotalMonths(yearsDecimal: number): number {
  const years = Math.floor(yearsDecimal);
  const months = Math.round((yearsDecimal - years) * 10);
  return years * 12 + months;
}
