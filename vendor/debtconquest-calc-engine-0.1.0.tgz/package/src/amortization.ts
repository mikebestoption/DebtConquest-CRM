/**
 * Standard closed-form fixed-payment loan amortization.
 * Ports `totalPaid(principal, apr, months)` from legacy script.js:824.
 */
export function amortizedPayment(principal: number, aprPercent: number, months: number): number {
  const r = aprPercent / 100 / 12;
  if (r === 0) return principal / months;
  return (principal * r) / (1 - Math.pow(1 + r, -months));
}

export interface AmortizedTotal {
  payment: number;
  totalPaid: number;
}

export function computeAmortizedTotal(
  principal: number,
  aprPercent: number,
  months: number,
): AmortizedTotal {
  const payment = amortizedPayment(principal, aprPercent, months);
  return { payment, totalPaid: payment * months };
}
