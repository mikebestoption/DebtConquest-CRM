import type { DebtInput } from "./types.js";

/**
 * Balance-weighted average APR across all given debts. Ports
 * `calculateWeightedAPR()` from legacy script.js:1789. Note: legacy calls
 * this over ALL debts (not filtered to active-only) - preserved as-is;
 * callers decide what subset to pass in.
 */
export function weightedAverageApr(debts: DebtInput[]): number {
  let totalBalance = 0;
  let totalWeighted = 0;
  for (const d of debts) {
    totalBalance += Number(d.balance);
    totalWeighted += Number(d.balance) * Number(d.apr);
  }
  if (totalBalance === 0) return 0;
  return Number((totalWeighted / totalBalance).toFixed(2));
}
