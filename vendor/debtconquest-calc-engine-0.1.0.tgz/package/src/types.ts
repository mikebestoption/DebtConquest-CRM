export interface DebtInput {
  name: string;
  balance: number;
  apr: number;
  min: number;
  active: boolean;
}

export type PayoffStrategy = "minimum" | "snowball" | "avalanche";

export interface PayoffResult {
  strategy: PayoffStrategy;
  months: number;
  totalInterest: number;
  totalPaid: number;
  warning: string | null;
}

export interface MonthRecord {
  month: number;
  payment: number;
  interest: number;
  balance: number;
}

export interface MinimumPaymentProblem {
  name: string;
  requiredMonthlyInterest: number;
  currentMinPayment: number;
}
