export interface SettlementRate {
  creditorName: string;
  settlementPercent: number;
}

const DEFAULT_SETTLEMENT_PERCENT = 50;

/**
 * Looks up a debt's settlement percentage by exact creditor-name match,
 * falling back to 50% if unmatched. Ports `calculateSettlement()` from
 * legacy script.js:1000.
 */
export function calculateSettlementAmount(
  debtName: string,
  balance: number,
  rates: SettlementRate[],
): number {
  const match = rates.find((r) => r.creditorName === debtName);
  const percent = match ? match.settlementPercent : DEFAULT_SETTLEMENT_PERCENT;
  return Number(balance) * (percent / 100);
}

export interface ProgramFee {
  feePercent: number;
  feeAmount: number;
}

/**
 * Tiered program fee on total enrolled principal. Ports `setProgramFee()`
 * from legacy script.js:1018.
 */
export function calculateProgramFee(totalPrincipal: number): ProgramFee {
  let feePercent = 0;
  if (totalPrincipal > 0 && totalPrincipal < 50000.01) feePercent = 27;
  else if (totalPrincipal > 50000 && totalPrincipal < 70000.01) feePercent = 25;
  else if (totalPrincipal > 70000 && totalPrincipal < 100000.01) feePercent = 24;
  else if (totalPrincipal > 100000) feePercent = 22;

  return { feePercent, feeAmount: (feePercent * totalPrincipal) / 100 };
}

export interface ProgramCostInputs {
  totalSettlementAmount: number;
  programMonths: number;
  programFeeAmount: number;
  bankFeeMonthly?: number;
  legalFeeMonthly?: number;
  enrollFee?: number;
}

export interface ProgramCostResult {
  totalCost: number;
  monthlyEmi: number;
}

/**
 * THE single authoritative "Total Estimated Program Cost" formula. Legacy had
 * two versions that silently disagreed by exactly `enrollFee` ($349):
 * `calculateDebtcon()` (script.js:939) included it, `initlinechart()`
 * (script.js:1116) didn't. This version always includes it - every UI
 * surface and every server-side calculation must call this one function so
 * the numbers can never diverge again.
 */
export function calculateProgramCost(inputs: ProgramCostInputs): ProgramCostResult {
  const {
    totalSettlementAmount,
    programMonths,
    programFeeAmount,
    bankFeeMonthly = 9.95,
    legalFeeMonthly = 54.95,
    enrollFee = 349,
  } = inputs;

  const totalCost =
    totalSettlementAmount + programMonths * (bankFeeMonthly + legalFeeMonthly) + programFeeAmount + enrollFee;

  return { totalCost, monthlyEmi: totalCost / programMonths };
}
