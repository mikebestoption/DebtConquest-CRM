import type {
  DebtInput,
  MinimumPaymentProblem,
  MonthRecord,
  PayoffResult,
  PayoffStrategy,
} from "./types.js";

const MAX_MONTHS_SAFETY_CAP = 1200; // 100 years hard stop, matches legacy simulatePayoff

interface SimDebt {
  name: string;
  balance: number;
  apr: number;
  min: number;
}

/**
 * Month-by-month multi-debt amortization across 3 strategies.
 * Ports `simulatePayoff()` from legacy script.js:181, including its
 * negative-amortization guard (auto-bumps a minimum payment that doesn't
 * even cover interest) and its 100-year safety cap.
 */
export function simulateMultiDebtPayoff(
  inputDebts: DebtInput[],
  monthlyBudget: number,
  strategy: PayoffStrategy,
): PayoffResult {
  const debts: SimDebt[] = inputDebts
    .filter((d) => d.active)
    .map((d) => ({ name: d.name, balance: Number(d.balance), apr: Number(d.apr), min: Number(d.min) }));

  let months = 0;
  let interestPaid = 0;
  let totalPaid = 0;
  let warning: string | null = null;

  if (debts.length === 0) {
    return { strategy, months: 0, totalInterest: 0, totalPaid: 0, warning: null };
  }

  const sumMins = debts.reduce((s, d) => s + Math.max(0, d.min), 0);
  const budget = Math.max(monthlyBudget, sumMins);

  let safety = 0;
  while (debts.some((d) => d.balance > 0.01)) {
    safety++;
    if (safety > MAX_MONTHS_SAFETY_CAP) {
      warning = "Payoff exceeds 100 years. Payment likely too low.";
      break;
    }

    const monthInterests = debts.map((d) => {
      const r = d.apr / 100 / 12;
      return d.balance > 0 ? Number((d.balance * r).toFixed(10)) : 0;
    });

    debts.forEach((d, i) => {
      if (d.balance <= 0) return;
      const interest = monthInterests[i];
      if (d.min <= interest) {
        d.min = Number((interest + 0.01).toFixed(2));
        warning = "Some minimum payments were too low to cover interest and were adjusted automatically.";
      }
    });

    const currentSumMins = debts.reduce((s, d, i) => {
      if (d.balance <= 0) return s;
      return s + Math.min(d.min, d.balance + monthInterests[i]);
    }, 0);

    let leftover = Math.max(0, budget - currentSumMins);

    let order = debts.map((_, i) => i);
    if (strategy === "snowball") {
      order = [...order].sort((a, b) => debts[a].balance - debts[b].balance);
    } else if (strategy === "avalanche") {
      order = [...order].sort((a, b) => debts[b].apr - debts[a].apr);
    } else if (strategy === "minimum") {
      leftover = 0;
    }

    const payments = debts.map((d, i) => (d.balance <= 0 ? 0 : Math.min(d.min, d.balance + monthInterests[i])));

    for (const i of order) {
      if (leftover <= 0) break;
      if (debts[i].balance <= 0) continue;
      const due = debts[i].balance + monthInterests[i] - payments[i];
      if (due <= 0) continue;
      const extra = Math.min(leftover, due);
      payments[i] += extra;
      leftover -= extra;
    }

    debts.forEach((d, i) => {
      if (d.balance <= 0) return;
      const interest = monthInterests[i];
      const pay = Math.min(payments[i], d.balance + interest);
      const principal = pay - interest;
      d.balance = Number(Math.max(0, d.balance - principal).toFixed(10));
      interestPaid += interest;
      totalPaid += pay;
    });

    months++;
  }

  return {
    strategy,
    months,
    totalInterest: Number(interestPaid.toFixed(2)),
    totalPaid: Number(totalPaid.toFixed(2)),
    warning,
  };
}

/**
 * Flags any active debt whose minimum payment doesn't even cover its own
 * first month of interest (would never amortize). Ports
 * `validateMinimumPayments()` from legacy script.js:529.
 */
export function validateMinimumPayments(debts: DebtInput[]): MinimumPaymentProblem[] {
  const problems: MinimumPaymentProblem[] = [];
  for (const d of debts) {
    if (!d.active || d.balance <= 0) continue;
    const monthlyInterest = (d.balance * (d.apr / 100)) / 12;
    if (Number(d.min) <= monthlyInterest) {
      problems.push({
        name: d.name,
        requiredMonthlyInterest: Number(monthlyInterest.toFixed(2)),
        currentMinPayment: Number(Number(d.min).toFixed(2)),
      });
    }
  }
  return problems;
}

/**
 * Per-month history (Date/Payment/Interest/Remaining Balance) using the
 * minimums-only strategy, for the "Minimum Payment History" modal.
 * Ports `getMinimumSchedule()` from legacy script.js:437.
 */
export function getMinimumPaymentSchedule(inputDebts: DebtInput[], monthlyBudget: number): MonthRecord[] {
  const debts: SimDebt[] = inputDebts
    .filter((d) => d.active)
    .map((d) => ({ name: d.name, balance: Number(d.balance), apr: Number(d.apr), min: Number(d.min) }));

  const minRequired = debts.reduce((s, d) => s + d.min, 0);
  const budget = Math.max(monthlyBudget, minRequired);
  const schedule: MonthRecord[] = [];
  let month = 1;
  let safety = 0;

  while (debts.some((d) => d.balance > 0.01)) {
    safety++;
    if (safety > 1000) break;

    const interests = debts.map((d) => {
      const r = d.apr / 100 / 12;
      return d.balance > 0 ? d.balance * r : 0;
    });

    const payments = debts.map((d, i) => {
      const due = d.balance + interests[i];
      return d.balance > 0 ? Math.min(d.min, due) : 0;
    });

    debts.forEach((d, i) => {
      if (d.balance <= 0) return;
      const interest = interests[i];
      const pay = payments[i];
      const principal = Math.max(0, pay - interest);
      d.balance = Math.max(0, d.balance - principal);
    });

    const totalBalance = debts.reduce((s, d) => s + d.balance, 0);
    const totalPayment = payments.reduce((s, p) => s + p, 0);
    const totalInterest = interests.reduce((s, i) => s + i, 0);

    schedule.push({
      month,
      payment: Number(totalPayment.toFixed(2)),
      interest: Number(totalInterest.toFixed(2)),
      balance: Number(totalBalance.toFixed(2)),
    });

    month++;
  }

  return schedule;
}
