import type { MonthRecord } from "./types.js";

export interface SingleBalancePayoffOptions {
  /** Charge the payment against balance+interest instead of just balance. Legacy default: false. */
  usePostInterestPayment?: boolean;
  /** Payment floor in dollars. Legacy default: 0. */
  minPaymentFloor?: number;
  /** Loop exits once balance falls to/under this, then force-closes. Legacy default: 0.01 (real payoff) or 190 (report scenario). */
  stopThreshold?: number;
  /**
   * Flat dollar amount subtracted from the final cleanup payment when the loop
   * exits via `stopThreshold` with balance still remaining. This exactly
   * reproduces an unexplained legacy constant (`script.js:786` and `:1953`,
   * `totalPaid + (balance - 36)`). Preserved as-is pending product sign-off -
   * see plan notes. Legacy default: 36.
   */
  forceCloseAdjustment?: number;
  /** Track full month-by-month history (Date/Principal/Interest/Payment/Remaining). Legacy: only calculateTotalPaybackfotrmail did this. */
  trackHistory?: boolean;
  /** Accumulate cumulative principal/interest/payment totals at 3/6/9/12-year cutoffs, for the personalized report email. */
  trackYearBuckets?: boolean;
}

export interface YearBucket {
  principal: number;
  interest: number;
  payment: number;
}

export interface SingleBalancePayoffResult {
  months: number;
  totalPaid: number;
  totalInterest: number;
  history?: MonthRecord[];
  yearBuckets?: {
    threeYear: YearBucket;
    sixYear: YearBucket;
    nineYear: YearBucket;
    twelveYear: YearBucket;
  };
}

/**
 * Single blended-balance amortization where the monthly payment is a
 * percentage of the current balance (the real-world credit-card "minimum
 * payment" formula), not a fixed amount. Unifies legacy's
 * `calculateTotalPayback` (script.js:728) and `calculateTotalPaybackfotrmail`
 * (script.js:1840, which additionally tracked per-month history and
 * 3/6/9/12-year cumulative buckets for the personalized report email) into
 * one parameterized function.
 */
export function simulateSingleBalancePayoff(
  balance: number,
  annualInterestRatePercent: number,
  minPaymentRatePercent: number,
  options: SingleBalancePayoffOptions = {},
): SingleBalancePayoffResult {
  const {
    usePostInterestPayment = false,
    minPaymentFloor = 0,
    stopThreshold = 0.01,
    forceCloseAdjustment = 36,
    trackHistory = false,
    trackYearBuckets = false,
  } = options;

  const monthlyRate = annualInterestRatePercent / 12 / 100;
  const fixedInterest = balance * monthlyRate; // legacy quirk: used as a constant for year-bucket "interest" accumulation, not the live per-month interest

  let months = 0;
  let totalPaid = 0;
  let totalInterest = 0;
  let counter = 0;

  const history: MonthRecord[] = [];
  const threeYear: YearBucket = { principal: 0, interest: 0, payment: 0 };
  const sixYear: YearBucket = { principal: 0, interest: 0, payment: 0 };
  const nineYear: YearBucket = { principal: 0, interest: 0, payment: 0 };
  const twelveYear: YearBucket = { principal: 0, interest: 0, payment: 0 };

  while (balance > stopThreshold && months < 10000) {
    let interest = balance * monthlyRate;
    const paymentBase = usePostInterestPayment ? balance + interest : balance;
    let payment = paymentBase * (minPaymentRatePercent / 100);

    if (payment < minPaymentFloor) payment = minPaymentFloor;
    if (payment <= interest) payment = interest + 0.01; // avoid negative amortization stall

    interest = Math.round(interest * 100) / 100;
    payment = Math.round(payment * 100) / 100;

    const principal = Math.round((payment - interest) * 100) / 100;
    const newBalance = Math.round((balance + interest - payment) * 100) / 100;
    totalPaid = Math.round((totalPaid + payment) * 100) / 100;

    if (trackHistory) {
      history.push({ month: months + 1, payment, interest, balance: newBalance });
    }

    if (trackYearBuckets) {
      if (counter < 36) { threeYear.principal += principal; threeYear.interest += fixedInterest; threeYear.payment += payment; }
      if (counter < 72) { sixYear.principal += principal; sixYear.interest += fixedInterest; sixYear.payment += payment; }
      if (counter < 108) { nineYear.principal += principal; nineYear.interest += fixedInterest; nineYear.payment += payment; }
      if (counter < 144) { twelveYear.principal += principal; twelveYear.interest += fixedInterest; twelveYear.payment += payment; }
    }

    balance = newBalance;
    months++;
    counter++;
    totalInterest += interest;
  }

  if (balance > 0) {
    totalPaid = Math.round((totalPaid + (balance - forceCloseAdjustment)) * 100) / 100;
    if (trackHistory) {
      history.push({ month: months + 1, payment: balance, interest: 0, balance: 0 });
    }
    months++;
    balance = 0;
  }

  const result: SingleBalancePayoffResult = { months, totalPaid, totalInterest: Number(totalInterest.toFixed(2)) };
  if (trackHistory) result.history = history;
  if (trackYearBuckets) result.yearBuckets = { threeYear, sixYear, nineYear, twelveYear };
  return result;
}
