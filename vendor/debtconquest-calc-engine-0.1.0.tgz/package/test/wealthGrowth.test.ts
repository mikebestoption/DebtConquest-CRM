import { describe, expect, it } from "vitest";
import { calculateWealthGrowth, yearsAndMonthsToTotalMonths } from "../src/wealthGrowth.js";

describe("yearsAndMonthsToTotalMonths", () => {
  it("interprets legacy's ambiguous 'years.months' notation correctly (4.6 = 4y 6mo, not 4.6 years)", () => {
    expect(yearsAndMonthsToTotalMonths(4.6)).toBe(54);
    expect(yearsAndMonthsToTotalMonths(26)).toBe(312);
  });
});

describe("calculateWealthGrowth (golden baseline from legacy futureValueAnnualCompounding())", () => {
  it("$500/mo, 4y6mo (54 months), 7% annual", () => {
    expect(calculateWealthGrowth(500, 54, 7)).toBe(31662.42);
  });

  it("$500/mo, 26 years (312 months), 7% annual", () => {
    expect(calculateWealthGrowth(500, 312, 7)).toBe(427682.72);
  });

  it("0 months returns 0", () => {
    expect(calculateWealthGrowth(500, 0, 7)).toBe(0);
  });
});
