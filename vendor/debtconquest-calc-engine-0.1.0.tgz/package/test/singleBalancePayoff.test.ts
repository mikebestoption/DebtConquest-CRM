import { describe, expect, it } from "vitest";
import { simulateSingleBalancePayoff } from "../src/singleBalancePayoff.js";
import { simulateFixedPaymentPayoff } from "../src/fixedPaymentPayoff.js";

const totalBalance = 19950; // sum of the "Load Example" debts

describe("simulateSingleBalancePayoff (golden baseline from legacy calculateTotalPayback)", () => {
  it("24% APR / 4% minimum payment, stopThreshold=190 (the report-email scenario)", () => {
    const result = simulateSingleBalancePayoff(totalBalance, 24, 4, { stopThreshold: 190 });
    expect(result.months).toBe(232);
    expect(result.totalPaid).toBe(39676.53);
  });

  it("defaults (stopThreshold=0.01, forceCloseAdjustment=36) still terminate", () => {
    const result = simulateSingleBalancePayoff(totalBalance, 24, 4);
    expect(result.months).toBeGreaterThan(0);
    expect(result.totalPaid).toBeGreaterThan(totalBalance);
  });

  it("tracks year-bucket accumulation and full history when requested", () => {
    const result = simulateSingleBalancePayoff(totalBalance, 24, 4, {
      stopThreshold: 190,
      trackHistory: true,
      trackYearBuckets: true,
    });
    expect(result.history).toHaveLength(result.months);
    expect(result.yearBuckets).toBeDefined();
    expect(result.yearBuckets!.threeYear.payment).toBeGreaterThan(0);
    expect(result.yearBuckets!.twelveYear.payment).toBeGreaterThanOrEqual(
      result.yearBuckets!.threeYear.payment,
    );
  });

  it("omits history/yearBuckets by default (no unnecessary work)", () => {
    const result = simulateSingleBalancePayoff(totalBalance, 24, 4, { stopThreshold: 190 });
    expect(result.history).toBeUndefined();
    expect(result.yearBuckets).toBeUndefined();
  });
});

describe("simulateFixedPaymentPayoff (golden baseline from legacy calculateWithoutCard)", () => {
  it("weighted APR 26.09%, fixed monthly payment = totalMin (750)", () => {
    const result = simulateFixedPaymentPayoff(totalBalance, 26.09, 750);
    expect(result.months).toBe(41);
    expect(result.totalPaid).toBe(30049);
  });
});
