import { describe, expect, it } from "vitest";
import { weightedAverageApr } from "../src/weightedApr.js";

describe("weightedAverageApr (golden baseline from legacy calculateWeightedAPR())", () => {
  it("balance-weights APR across the 'Load Example' debts", () => {
    const debts = [
      { name: "Amazon Card", balance: 1250, apr: 27.99, min: 40, active: true },
      { name: "Capital One", balance: 11800, apr: 27.99, min: 500, active: true },
      { name: "Chase Sapphire", balance: 6900, apr: 22.49, min: 210, active: true },
    ];
    expect(weightedAverageApr(debts)).toBe(26.09);
  });

  it("returns 0 when total balance is 0", () => {
    expect(weightedAverageApr([{ name: "Empty", balance: 0, apr: 10, min: 0, active: true }])).toBe(0);
  });
});
