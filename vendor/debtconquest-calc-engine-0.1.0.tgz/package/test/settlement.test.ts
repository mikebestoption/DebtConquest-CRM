import { describe, expect, it } from "vitest";
import { calculateProgramCost, calculateProgramFee, calculateSettlementAmount } from "../src/settlement.js";

describe("calculateSettlementAmount (golden baseline from legacy calculateSettlement())", () => {
  it("falls back to 50% when the creditor has no matching rate", () => {
    expect(calculateSettlementAmount("Some Unknown Creditor", 10000, [])).toBe(5000);
  });

  it("uses the matched rate when a creditor name matches exactly", () => {
    const rate = calculateSettlementAmount("Capital One", 11800, [
      { creditorName: "Capital One", settlementPercent: 40 },
    ]);
    expect(rate).toBe(4720);
  });
});

describe("calculateProgramFee (golden baseline from legacy setProgramFee())", () => {
  it("27% tier: 0 < P <= 50000", () => {
    expect(calculateProgramFee(25000)).toEqual({ feePercent: 27, feeAmount: 6750 });
  });
  it("25% tier: 50000 < P <= 70000", () => {
    expect(calculateProgramFee(60000)).toEqual({ feePercent: 25, feeAmount: 15000 });
  });
  it("24% tier: 70000 < P <= 100000", () => {
    expect(calculateProgramFee(85000)).toEqual({ feePercent: 24, feeAmount: 20400 });
  });
  it("22% tier: P > 100000", () => {
    expect(calculateProgramFee(150000)).toEqual({ feePercent: 22, feeAmount: 33000 });
  });
});

describe("calculateProgramCost - fixes the legacy $349 disagreement", () => {
  it("always includes enrollFee in the total (script.js:939 behavior, not the script.js:1116 omission)", () => {
    const withDefault = calculateProgramCost({
      totalSettlementAmount: 10000,
      programMonths: 36,
      programFeeAmount: 5000,
    });
    const withoutEnrollFee =
      10000 + 36 * (9.95 + 54.95) + 5000; // the legacy script.js:1116 formula, omitting enrollFee
    expect(withDefault.totalCost).toBe(withoutEnrollFee + 349);
  });

  it("monthlyEmi is totalCost / programMonths", () => {
    const result = calculateProgramCost({
      totalSettlementAmount: 10000,
      programMonths: 36,
      programFeeAmount: 5000,
    });
    expect(result.monthlyEmi).toBeCloseTo(result.totalCost / 36, 8);
  });
});
