import { describe, expect, it } from "vitest";
import {
  getMinimumPaymentSchedule,
  simulateMultiDebtPayoff,
  validateMinimumPayments,
} from "../src/multiDebtPayoff.js";
import type { DebtInput } from "../src/types.js";

// Fixture: the exact "Load Example" debts baked into legacy script.js
const exampleDebts: DebtInput[] = [
  { name: "Amazon Card", balance: 1250, apr: 27.99, min: 40, active: true },
  { name: "Capital One", balance: 11800, apr: 27.99, min: 500, active: true },
  { name: "Chase Sapphire", balance: 6900, apr: 22.49, min: 210, active: true },
];
const totalMin = 750;

describe("simulateMultiDebtPayoff (golden baseline from legacy script.js)", () => {
  it("minimum strategy at budget=totalMin", () => {
    const result = simulateMultiDebtPayoff(exampleDebts, totalMin, "minimum");
    expect(result).toEqual({
      strategy: "minimum",
      months: 57,
      totalInterest: 10473.47,
      totalPaid: 30423.47,
      warning: null,
    });
  });

  it("snowball strategy at budget=totalMin", () => {
    const result = simulateMultiDebtPayoff(exampleDebts, totalMin, "snowball");
    expect(result).toEqual({
      strategy: "snowball",
      months: 40,
      totalInterest: 9969.42,
      totalPaid: 29919.42,
      warning: null,
    });
  });

  it("avalanche strategy at budget=totalMin", () => {
    const result = simulateMultiDebtPayoff(exampleDebts, totalMin, "avalanche");
    expect(result).toEqual({
      strategy: "avalanche",
      months: 40,
      totalInterest: 9969.42,
      totalPaid: 29919.42,
      warning: null,
    });
  });

  it("snowball strategy at a higher budget pays off faster with more interest saved than avalanche at the same budget", () => {
    const snowball = simulateMultiDebtPayoff(exampleDebts, 1000, "snowball");
    const avalanche = simulateMultiDebtPayoff(exampleDebts, 1000, "avalanche");
    expect(snowball).toEqual({
      strategy: "snowball",
      months: 27,
      totalInterest: 6585.29,
      totalPaid: 26535.29,
      warning: null,
    });
    expect(avalanche).toEqual({
      strategy: "avalanche",
      months: 27,
      totalInterest: 6272.32,
      totalPaid: 26222.32,
      warning: null,
    });
    // Avalanche always pays less or equal total interest than snowball at an
    // identical budget - this is a mathematical invariant of the strategies,
    // not just a fixture assertion.
    expect(avalanche.totalInterest).toBeLessThanOrEqual(snowball.totalInterest);
  });

  it("ignores inactive debts", () => {
    const withInactive: DebtInput[] = [
      ...exampleDebts,
      { name: "Ignored Card", balance: 99999, apr: 99, min: 1, active: false },
    ];
    const result = simulateMultiDebtPayoff(withInactive, totalMin, "minimum");
    expect(result.months).toBe(57);
    expect(result.totalPaid).toBe(30423.47);
  });

  it("returns zeros for an empty debt list", () => {
    expect(simulateMultiDebtPayoff([], 500, "minimum")).toEqual({
      strategy: "minimum",
      months: 0,
      totalInterest: 0,
      totalPaid: 0,
      warning: null,
    });
  });

  it("auto-bumps a minimum payment that doesn't cover interest instead of looping forever", () => {
    const badDebt: DebtInput[] = [{ name: "Trap", balance: 10000, apr: 29.99, min: 1, active: true }];
    const result = simulateMultiDebtPayoff(badDebt, 1, "minimum");
    expect(result.months).toBeGreaterThan(0);
    expect(result.months).toBeLessThan(1200);
    expect(result.warning).toMatch(/adjusted automatically/);
  });
});

describe("validateMinimumPayments", () => {
  it("flags a debt whose minimum doesn't cover its own first-month interest", () => {
    const problems = validateMinimumPayments([
      { name: "Trap", balance: 10000, apr: 24, min: 50, active: true },
    ]);
    expect(problems).toHaveLength(1);
    expect(problems[0].name).toBe("Trap");
    expect(problems[0].requiredMonthlyInterest).toBe(200);
  });

  it("passes when every active debt's minimum covers its interest", () => {
    expect(validateMinimumPayments(exampleDebts)).toEqual([]);
  });

  it("ignores inactive debts", () => {
    expect(
      validateMinimumPayments([{ name: "Trap", balance: 10000, apr: 24, min: 1, active: false }]),
    ).toEqual([]);
  });
});

describe("getMinimumPaymentSchedule", () => {
  it("produces a month-by-month schedule that ends with a near-zero balance", () => {
    const schedule = getMinimumPaymentSchedule(exampleDebts, totalMin);
    expect(schedule.length).toBe(57);
    expect(schedule[0].month).toBe(1);
    expect(schedule[schedule.length - 1].balance).toBeLessThanOrEqual(0.01);
  });
});
