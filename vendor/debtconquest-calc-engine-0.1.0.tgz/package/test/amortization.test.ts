import { describe, expect, it } from "vitest";
import { computeAmortizedTotal } from "../src/amortization.js";

const totalBalance = 19950;

describe("computeAmortizedTotal (golden baseline from legacy totalPaid())", () => {
  it("Credit Counseling default: 8.0% APR / 48 months", () => {
    const { totalPaid } = computeAmortizedTotal(totalBalance, 8.0, 48);
    expect(totalPaid).toBeCloseTo(23377.81, 2);
  });

  it("Personal Loan Consolidation default: 14.9% APR / 60 months", () => {
    const { totalPaid } = computeAmortizedTotal(totalBalance, 14.9, 60);
    expect(totalPaid).toBeCloseTo(28413.75, 2);
  });

  it("0% APR pays back exactly the principal", () => {
    const { totalPaid, payment } = computeAmortizedTotal(12000, 0, 24);
    expect(totalPaid).toBeCloseTo(12000, 5);
    expect(payment).toBeCloseTo(500, 5);
  });
});
